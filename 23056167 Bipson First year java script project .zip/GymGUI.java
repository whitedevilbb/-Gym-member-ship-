import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFileChooser;
import java.io.BufferedWriter;
import java.io.*;

public class GymGUI {
    private JFrame frame;
    private ArrayList<GymMember> members = new ArrayList<>();
    
    private JPanel regularPanel;
    private JLabel idLabel, nameLabel, locationLabel, phoneLabel, emailLabel;
    private JTextField idTXF, nameTXF, locationTXF, phoneTXF, emailTXF;
    private JRadioButton maleRadioButton, femaleRadioButton, otherRadioButton;
    private ButtonGroup genderGroup;
    private JPanel regularMemberPanel;
    private JPanel premiumMemberPanel;

    public static void main(String[] args) {
        new GymGUI().initialize();
    }

    public void initialize() {
        frame = new JFrame("Gym Membership System"); 
        frame.setLayout(null);
        frame.setSize(1000, 800);
        frame.getContentPane().setBackground(new Color(240, 240, 240));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        regularMemberPanel = new JPanel();
        regularMemberPanel.setLayout(null);
        regularMemberPanel.setBounds(20, 20, 450, 500);
        regularMemberPanel.setBorder(BorderFactory.createTitledBorder("Regular Member Information"));
        regularMemberPanel.setBackground(new Color(220, 240, 255));
        
        premiumMemberPanel = new JPanel();
        premiumMemberPanel.setLayout(null);
        premiumMemberPanel.setBounds(500, 20, 450, 500);
        premiumMemberPanel.setBorder(BorderFactory.createTitledBorder("Premium Member Information"));
        premiumMemberPanel.setBackground(new Color(220, 255, 240));
        
        JTextField memberIdField = new JTextField();
        memberIdField.setBounds(120, 30, 150, 30);
        regularMemberPanel.add(memberIdField);
        
        JLabel memberIdLabel = new JLabel("MemberID");
        memberIdLabel.setBounds(20, 30, 100, 30);
        memberIdField.setBounds(120, 30, 150, 30);
        
        JLabel memberNameLabel = new JLabel("Member Name");
        memberNameLabel.setBounds(20, 70, 100, 30);
        JTextField memberNameField = new JTextField();
        memberNameField.setBounds(120, 70, 150, 30);
        
        JLabel locationLabel = new JLabel("Location");
        locationLabel.setBounds(20, 110, 100, 30);
        JTextField locationField = new JTextField();
        locationField.setBounds(120, 110, 150, 30);
        
        JLabel phoneLabel = new JLabel("Phone");
        phoneLabel.setBounds(20, 150, 100, 30);
        JTextField phoneField = new JTextField();
        phoneField.setBounds(120, 150, 150, 30);
        
        JLabel emailLabel = new JLabel("Email");
        emailLabel.setBounds(20, 190, 100, 30);
        JTextField emailField = new JTextField();
        emailField.setBounds(120, 190, 150, 30);
        
        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setBounds(20, 230, 100, 30);
        JRadioButton maleRadio = new JRadioButton("Male");
        maleRadio.setBounds(120, 230, 70, 30);
        JRadioButton femaleRadio = new JRadioButton("Female");
        femaleRadio.setBounds(200, 230, 75, 30);
        JRadioButton otherRadio = new JRadioButton("Other");
        otherRadio.setBounds(280, 230, 70, 30);
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        genderGroup.add(otherRadio);
        maleRadio.setSelected(true);
        
        JLabel dobLabel = new JLabel("DOB");
        dobLabel.setBounds(20, 270, 100, 30);
        
        JComboBox<String> dobYearComboBox = new JComboBox<>();
        for (int i = 1900; i <= 2020; i++) {
            dobYearComboBox.addItem(String.valueOf(i));
        }
        dobYearComboBox.setBounds(120, 270, 70, 30);
        
        JComboBox<String> dobMonthComboBox = new JComboBox<>();
        String[] monthNames = {"January", "February", "March", "April", "May", "June", 
                       "July", "August", "September", "October", "November", "December"};
        for (int i = 1; i <= 12; i++) {
            dobMonthComboBox.addItem(i + "-" + monthNames[i-1]);
        }
        dobMonthComboBox.setBounds(200, 270, 100, 30);
        
        JComboBox<String> dobDayComboBox = new JComboBox<>();
        for (int i = 1; i <= 31; i++) {
            dobDayComboBox.addItem(String.valueOf(i));
        }
        dobDayComboBox.setBounds(310, 270, 50, 30);
        
        JLabel startDateLabel = new JLabel("Start Date");
        startDateLabel.setBounds(20, 310, 100, 30);
        
        JComboBox<String> msYearComboBox = new JComboBox<>();
        for (int i = 2020; i <= 2025; i++) {
            msYearComboBox.addItem(String.valueOf(i));
        }
        msYearComboBox.setBounds(120, 310, 70, 30);
        
        JComboBox<String> msMonthComboBox = new JComboBox<>();
        for (int i = 1; i <= 12; i++) {
            msMonthComboBox.addItem(i + "-" + monthNames[i-1]);
        }
        msMonthComboBox.setBounds(200, 310, 100, 30);
        
        JComboBox<String> msDayComboBox = new JComboBox<>();
        for (int i = 1; i <= 31; i++) {
            msDayComboBox.addItem(String.valueOf(i));
        }
        msDayComboBox.setBounds(310, 310, 50, 30);
        
        JLabel referralLabel = new JLabel("Referral Source");
        referralLabel.setBounds(20, 350, 100, 30);
        JTextField referralField = new JTextField();
        referralField.setBounds(120, 350, 150, 30);
        
        JLabel paidLabel = new JLabel("Paid Amount");
        paidLabel.setBounds(20, 390, 100, 30);
        JTextField paidField = new JTextField();
        paidField.setBounds(120, 390, 150, 30);
        
        JLabel removalLabel = new JLabel("Removal Reason");
        removalLabel.setBounds(20, 430, 100, 30);
        JTextField removalField = new JTextField();
        removalField.setBounds(120, 430, 150, 30);
        
        JLabel planLabel = new JLabel("Plan ");
        planLabel.setBounds(300, 30, 150, 30);
        String[] plans = {"Basic", "Standard", "Deluxe"};
        JComboBox<String> planComboBox = new JComboBox<>(plans);
        planComboBox.setBounds(400, 30, 150, 30);
        
        JLabel priceLabel = new JLabel("Regular Price");
        priceLabel.setBounds(300, 70, 100, 30);
        JTextField priceField = new JTextField("6500");
        priceField.setEditable(false);
        priceField.setBounds(400, 70, 150, 30);
        
        JLabel premiumLabel = new JLabel("Premium Charge");
        premiumLabel.setBounds(300, 110, 100, 30);
        JTextField premiumField = new JTextField("10000");
        premiumField.setEditable(false);
        premiumField.setBounds(400, 110, 150, 30);
        
        JLabel discountLabel = new JLabel("Discount Amount");
        discountLabel.setBounds(300, 150, 100, 30);
        JTextField discountField = new JTextField("0");
        discountField.setEditable(false);
        discountField.setBounds(400, 150, 150, 30);
        
        JLabel trainerLabel = new JLabel("Trainer's Name");
        trainerLabel.setBounds(300, 190, 100, 30);
        JTextField trainerField = new JTextField();
        trainerField.setBounds(400, 190, 150, 30);
        
        JButton addRegularButton = new JButton("Add Regular Member");
        addRegularButton.setBounds(700, 230, 190, 30);
        
        JButton addPremiumButton = new JButton("Add Premium Member");
        addPremiumButton.setBounds(700, 270, 190, 30);
        
        JButton activateButton = new JButton("Activate Membership");
        activateButton.setBounds(700, 310, 190, 30);
        
        JButton attendanceButton = new JButton("Mark Attendance");
        attendanceButton.setBounds(700, 350, 190, 30);
        
        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(700, 390, 190, 30);
        
        JButton deactivateButton = new JButton("Deactivate Membership");
        deactivateButton.setBounds(700, 430, 190, 30);
        
        JButton revertRegularButton = new JButton("Revert Regular");
        revertRegularButton.setBounds(500, 230, 180, 30);
        
        JButton revertPremiumButton = new JButton("Revert Premium");
        revertPremiumButton.setBounds(500, 270, 180, 30);
        
        JButton displayButton = new JButton("Display All");
        displayButton.setBounds(500, 310, 180, 30);
        
        JButton saveButton = new JButton("Save to File");
        saveButton.setBounds(500, 350, 180, 30);

        JButton loadButton = new JButton("Read from File");
        loadButton.setBounds(500, 390, 180, 30);

        JButton discountButton = new JButton("Calculate Discount");
        discountButton.setBounds(500, 430, 180, 30);

        JButton updatePlanButton = new JButton("Update Plan");
        updatePlanButton.setBounds(500, 470, 180, 30);
        
        frame.add(memberIdLabel);
        frame.add(memberIdField);
        frame.add(memberNameLabel);
        frame.add(memberNameField);
        frame.add(locationLabel);
        frame.add(locationField);
        frame.add(phoneLabel);
        frame.add(phoneField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(genderLabel);
        frame.add(maleRadio);
        frame.add(femaleRadio);
        frame.add(otherRadio);
        frame.add(dobLabel);
        frame.add(dobYearComboBox);
        frame.add(dobMonthComboBox);
        frame.add(dobDayComboBox);
        frame.add(startDateLabel);
        frame.add(msYearComboBox);
        frame.add(msMonthComboBox);
        frame.add(msDayComboBox);
        frame.add(referralLabel);
        frame.add(referralField);
        frame.add(paidLabel);
        frame.add(paidField);
        frame.add(removalLabel);
        frame.add(removalField);
        frame.add(planLabel);
        frame.add(planComboBox);
        frame.add(priceLabel);
        frame.add(priceField);
        frame.add(premiumLabel);
        frame.add(premiumField);
        frame.add(discountLabel);
        frame.add(discountField);
        frame.add(trainerLabel);
        frame.add(trainerField);
        frame.add(addRegularButton);
        frame.add(addPremiumButton);
        frame.add(activateButton);
        frame.add(attendanceButton);
        frame.add(clearButton);
        frame.add(deactivateButton);
        frame.add(revertRegularButton);
        frame.add(revertPremiumButton);
        frame.add(displayButton);
        frame.add(saveButton);
        frame.add(loadButton);
        frame.add(discountButton);
        frame.add(updatePlanButton);
        
        
        

        // Action listeners
        addRegularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = memberIdField.getText();
                String memberName = memberNameField.getText();
                String location = locationField.getText();
                String phone = phoneField.getText();
                String email = emailField.getText();
                String gender = maleRadio.isSelected() ? "Male" : femaleRadio.isSelected() ? "Female" : "Other";
                String dob = dobYearComboBox.getSelectedItem() + "-" + 
                           dobMonthComboBox.getSelectedItem() + "-" + 
                           dobDayComboBox.getSelectedItem();
                String startDate = msYearComboBox.getSelectedItem() + "-" + 
                                 msMonthComboBox.getSelectedItem() + "-" + 
                                 msDayComboBox.getSelectedItem();
                String plan = (String) planComboBox.getSelectedItem();
                String referral = referralField.getText();

                if (memberIdStr.isEmpty() || memberName.isEmpty() || location.isEmpty() || 
                    phone.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all required fields", "Incomplete Form", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                

                if (!phone.matches("\\d+")) {
                    JOptionPane.showMessageDialog(frame, "Phone number must contain only numbers", "Invalid Phone", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (!trainerField.getText().isEmpty()){
            JOptionPane.showMessageDialog(frame, "Regular member cannot have trainer!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

                try {
                    int memberId = Integer.parseInt(memberIdStr);
                    
                    if (isMemberIdExists(memberId)) {
                        JOptionPane.showMessageDialog(frame, "Member ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    RegularMember newMember = new RegularMember(
                        memberId, memberName, location, phone, email, 
                        gender, dob, startDate, referral);
                    
                    double planPrice = newMember.getPlanPrice(plan);
                    priceField.setText(String.valueOf(planPrice));
                    
                    members.add(newMember);
                    JOptionPane.showMessageDialog(frame, "Regular member added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid Member ID (number)", "Error", JOptionPane.ERROR_MESSAGE);
                }
                if (! trainerField.getText().isEmpty()){
                    JOptionPane.showMessageDialog(frame, "Regular member canot have trainer!","Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        });
        
        addPremiumButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = memberIdField.getText();
                String memberName = memberNameField.getText();
                String location = locationField.getText();
                String phone = phoneField.getText();
                String email = emailField.getText();
                String gender = maleRadio.isSelected() ? "Male" : femaleRadio.isSelected() ? "Female" : "Other";
                String dob = dobYearComboBox.getSelectedItem() + "-" + 
                           dobMonthComboBox.getSelectedItem() + "-" + 
                           dobDayComboBox.getSelectedItem();
                String startDate = msYearComboBox.getSelectedItem() + "-" + 
                                 msMonthComboBox.getSelectedItem() + "-" + 
                                 msDayComboBox.getSelectedItem();
                String trainer = trainerField.getText();

                if (memberIdStr.isEmpty() || memberName.isEmpty() || location.isEmpty() || 
                    phone.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all required fields", "Incomplete Form", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if (!phone.matches("\\d+")) {
                    JOptionPane.showMessageDialog(frame, "Phone number must contain only numbers", "Invalid Phone", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int memberId = Integer.parseInt(memberIdStr);
                    
                    if (isMemberIdExists(memberId)) {
                        JOptionPane.showMessageDialog(frame, "Member ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (trainer.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Please enter trainer's name for premium members", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    PremiumMember newMember = new PremiumMember(
                        memberId, memberName, location, phone, email, 
                        gender, dob, startDate, trainer);
                    
                    members.add(newMember);
                    JOptionPane.showMessageDialog(frame, "Premium member added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid Member ID (number)", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        activateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = memberIdField.getText();
                if (memberIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter Member ID", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int memberId = Integer.parseInt(memberIdStr);
                    GymMember member = findMemberById(memberId);
                    
                    if (member != null) {
                        member.activateMembership();
                        JOptionPane.showMessageDialog(frame, "Membership activated for ID: " + memberId, "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Member not found with ID: " + memberId, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid Member ID (number)", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        deactivateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = memberIdField.getText();
                if (memberIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter Member ID", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int memberId = Integer.parseInt(memberIdStr);
                    GymMember member = findMemberById(memberId);
                    
                    if (member != null) {
                        member.deactivateMembership();
                        JOptionPane.showMessageDialog(frame, "Membership deactivated for ID: " + memberId, "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Member not found with ID: " + memberId, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid Member ID (number)", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
    attendanceButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String memberIdStr = memberIdField.getText();
        if (memberIdStr.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter Member ID", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int memberId = Integer.parseInt(memberIdStr);
            GymMember member = findMemberById(memberId);
            
            if (member != null) {
                if (member.isActive()) {
                    member.markAttendance();
                    StringBuilder details = new StringBuilder();
                    details.append("=== Attendance Marked ===\n");
                    details.append("Member ID: ").append(member.getId()).append("\n");
                    details.append("Name: ").append(member.getName()).append("\n");
                    details.append("Type: ").append(member instanceof PremiumMember ? "Premium" : "Regular").append("\n");
                    details.append("Total Attendances: ").append(member.getAttendance()).append("\n");
                    details.append("Loyalty Points: ").append(member.getLoyaltyPoints()).append("\n");
                    details.append("Status: Active\n");
                    
                    JOptionPane.showMessageDialog(frame, 
                        details.toString(),  
                        "Attendance Confirmation", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, 
                        "Member is not active. Cannot mark attendance.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(frame, 
                    "Member not found with ID: " + memberId, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, 
                "Please enter a valid Member ID (number)", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});
        
        
                    
                
                
        
        
        revertRegularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = memberIdField.getText();
                if (memberIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter Member ID", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int memberId = Integer.parseInt(memberIdStr);
                    GymMember member = findRegularMemberById(memberId);
                    
                    if (member != null) {
                        members.remove(member);
                        JOptionPane.showMessageDialog(frame, 
                            "Regular member reverted for ID: " + memberId, 
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(frame, 
                            "Regular member not found with ID: " + memberId, 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, 
                        "Please enter a valid Member ID (number)", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        revertPremiumButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = memberIdField.getText();
                if (memberIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter Member ID", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int memberId = Integer.parseInt(memberIdStr);
                    GymMember member = findPremiumMemberById(memberId);
                    
                    if (member != null) {
                        members.remove(member);
                        JOptionPane.showMessageDialog(frame, 
                            "Premium member reverted for ID: " + memberId, 
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(frame, 
                            "Premium member not found with ID: " + memberId, 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, 
                        "Please enter a valid Member ID (number)", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (members.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, 
                        "No members to display", 
                        "Information", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("============ All Members =============\n\n");
                
                for (GymMember member : members) {
                    sb.append(member.toString()).append("\n\n");
                }

                JTextArea textArea = new JTextArea(sb.toString());
                textArea.setEditable(false);
                JScrollPane scrollPane = new JScrollPane(textArea);
                scrollPane.setPreferredSize(new Dimension(500, 400));
                
                JOptionPane.showMessageDialog(frame, scrollPane, 
                    "All Members", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                memberIdField.setText("");
                memberNameField.setText("");
                locationField.setText("");
                phoneField.setText("");
                emailField.setText("");
                maleRadio.setSelected(true);
                dobYearComboBox.setSelectedIndex(0);
                dobMonthComboBox.setSelectedIndex(0);
                dobDayComboBox.setSelectedIndex(0);
                msYearComboBox.setSelectedIndex(0);
                msMonthComboBox.setSelectedIndex(0);
                msDayComboBox.setSelectedIndex(0);
                referralField.setText("");
                paidField.setText("");
                removalField.setText("");
                planComboBox.setSelectedIndex(0);
                priceField.setText("6500");
                premiumField.setText("10000");
                discountField.setText("0");
                trainerField.setText("");
            }
        });

        // ===== NEWLY ADDED FUNCTIONALITIES =====
saveButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("MemberDetails.txt"))) {
            // Write table header
            writer.write("+------+-----------------+--------------+-------------+--------------------------+------------+-------+---------+-----------+------------+------------+---------+--------+\n");
            writer.write("| ID   | Name            | Location     | Phone       | Email                   | Start Date | Plan  | Price   | Attendance | Loyalty    | Active     | Payment | Discount |\n");
            writer.write("+------+-----------------+--------------+-------------+--------------------------+------------+-------+---------+-----------+------------+---------+--------+\n");
            
            for (GymMember member : members) {
                if (member instanceof RegularMember) {
                    RegularMember rm = (RegularMember)member;
                    writer.write(String.format("| %-4d | %-15s | %-12s | %-11s | %-24s | %-10s | %-5s | $%-7.2f | %-10d | %-10.2f | %-9s | %-7s | %-7.2f |%n",
                        rm.getId(),
                        rm.getName(),
                        rm.getLocation(),
                        rm.getPhone(),
                        rm.getEmail(),
                        rm.getMembershipStartDate(),
                        rm.getPlan(),
                        rm.getPrice(),
                        rm.getAttendance(),
                        rm.getLoyaltyPoints(),
                        rm.isActive() ? "Active" : "Inactive",
                        "N/A",
                        rm.calculateDiscount()));
                } else if (member instanceof PremiumMember) {
                    PremiumMember pm = (PremiumMember)member;
                    writer.write(String.format("| %-4d | %-15s | %-12s | %-11s | %-24s | %-10s | %-5s | $%-7.2f | %-10d | %-10.2f | %-9s | %-7s | %-7.2f |%n",
                        pm.getId(),
                        pm.getName(),
                        pm.getLocation(),
                        pm.getPhone(),
                        pm.getEmail(),
                        pm.getMembershipStartDate(),
                        "Premium",
                        pm.getPrice(),
                        pm.getAttendance(),
                        pm.getLoyaltyPoints(),
                        pm.isActive() ? "Active" : "Inactive",
                        pm.isFullPayment() ? "Paid" : "Pending",
                        pm.getDiscountAmount()));
                }
            }
            writer.write("+------+-----------------+--------------+-------------+--------------------------+------------+-------+---------+-----------+------------+---------+--------+\n");
            
            JOptionPane.showMessageDialog(frame, 
                "Member details saved in table format!", 
                "Success", JOptionPane.INFORMATION_MESSAGE);
                
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame,
                "Error saving members: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});

 loadButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent event) {  // Changed parameter name from 'e' to 'event'
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Member Data File");
        
        // Set default directory (optional)
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        
        int returnValue = fileChooser.showOpenDialog(frame);
        
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            int loadedCount = 0;
            int errorCount = 0;
            StringBuilder errorMessages = new StringBuilder();
            
            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile))) {
                members.clear(); // Clear existing members
                String line;
                
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    
                    String[] parts = line.split(",");
                    try {
                        GymMember member = null;
                        if (parts[0].equals("Regular") && parts.length >= 12) {
                            member = RegularMember.fromFileString(parts);
                        } else if (parts[0].equals("Premium") && parts.length >= 10) {
                            member = PremiumMember.fromFileString(parts);
                        }
                        
                        if (member != null) {
                            members.add(member);
                            loadedCount++;
                        } else {
                            errorCount++;
                            errorMessages.append("Invalid format: ").append(line).append("\n");
                        }
                    } catch (Exception ex) {  // Changed variable name from 'e' to 'ex'
                        errorCount++;
                        errorMessages.append("Error parsing: ").append(line)
                                    .append(" - ").append(ex.getMessage()).append("\n");
                    }
                }
                
                // Show results to user
                String message = "Loaded " + loadedCount + " members successfully";
                if (errorCount > 0) {
                    message += "\n" + errorCount + " errors occurred";
                    JOptionPane.showMessageDialog(frame, 
                        message + "\n\nError details:\n" + errorMessages.toString(),
                        "Load Complete with Errors", 
                        JOptionPane.WARNING_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, 
                        message,
                        "Load Complete", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
                
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(frame,
                    "File not found: " + selectedFile.getName(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame,
                    "Error reading file: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
});

        discountButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String memberIdStr = memberIdField.getText();
        if (memberIdStr.isEmpty()) {
            JOptionPane.showMessageDialog(frame, 
                "Please enter Member ID", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int memberId = Integer.parseInt(memberIdStr);
            GymMember member = findMemberById(memberId);
            
            if (member != null) {
                if (member instanceof RegularMember) {
                    double discount = ((RegularMember)member).calculateDiscount();
                    discountField.setText(String.valueOf(discount));
                    JOptionPane.showMessageDialog(frame, 
                        "Discount calculated: " + discount, 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                } else if (member instanceof PremiumMember) {
                    ((PremiumMember)member).calculateDiscount();
                    double discount = ((PremiumMember)member).getDiscountAmount();
                    discountField.setText(String.valueOf(discount));
                    JOptionPane.showMessageDialog(frame, 
                        "Premium discount calculated: " + discount, 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(frame, 
                    "Member not found with ID: " + memberId, 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, 
                "Please enter a valid Member ID (number)", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});
        updatePlanButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = memberIdField.getText();
                String plan = (String) planComboBox.getSelectedItem();
                
                if (memberIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, 
                        "Please enter Member ID", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int memberId = Integer.parseInt(memberIdStr);
                    GymMember member = findMemberById(memberId);
                    
                    if (member != null) {
                        if (member instanceof RegularMember) {
                            ((RegularMember)member).setPlan(plan);
                            double price = ((RegularMember)member).getPlanPrice(plan);
                            priceField.setText(String.valueOf(price));
                            JOptionPane.showMessageDialog(frame, 
                                "Plan updated to " + plan + " for member ID: " + memberId, 
                                "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(frame, 
                                "Plan update only available for regular members", 
                                "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, 
                            "Member not found with ID: " + memberId, 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, 
                        "Please enter a valid Member ID (number)", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        
        

        frame.setVisible(true);
    }

    private boolean isMemberIdExists(int memberId) {
        for (GymMember member : members) {
            if (member.getId() == memberId) {
                return true;
            }
        }
        return false;
    }
    
    private GymMember findMemberById(int memberId) {
        for (GymMember member : members) {
            if (member.getId() == memberId) {
                return member;
            }
        }
        return null;
    }   
    
    private GymMember findRegularMemberById(int memberId) {
        for (GymMember member : members) {
            if (member.getId() == memberId && member instanceof RegularMember) {
                return member;
            }
        }
        return null;
    }

    private GymMember findPremiumMemberById(int memberId) {
        for (GymMember member : members) {
            if (member.getId() == memberId && member instanceof PremiumMember) {
                return member;
            }
        }
        return null;
    }
}