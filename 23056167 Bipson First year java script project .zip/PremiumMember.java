public class PremiumMember extends GymMember {
    private final double premiumCharge = 50000;
    private String personalTrainer;
    private boolean isFullPayment;
    private double paidAmount;
    private double discountAmount;

    // Constructor
    public PremiumMember(int id, String name, String location, String phone, String email, String gender, String DOB, String membershipStartDate, String personalTrainer) {
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        this.personalTrainer = personalTrainer;
        this.isFullPayment = false;
        this.paidAmount = 0;
        this.discountAmount = 0;
    }

  // Add this method to PremiumMember class
     public double getPrice() {
    return premiumCharge - discountAmount;
     }
     
    public double getPremiumCharge() { 
        return premiumCharge; 
    }
    
    public String getPersonalTrainer() { 
        return personalTrainer; 
    }
    
    public boolean isFullPayment() { 
        return isFullPayment; 
    }
    
    public double getPaidAmount() { 
        return paidAmount; 
    } 
    
    public double getDiscountAmount() { 
        return discountAmount; 
    }
        
    @Override
    public void activateMembership() {
        if (!this.activeStatus) {  // Premium members need to have made full payment before activation
            super.activateMembership();  // Call the parent method to set activeStatus = true
            System.out.println("Premium membership activated successfully.");
        } else {
            System.out.println("Cannot activate premium membership. Full payment is required.");
        }
    }
    
    @Override
    public void deactivateMembership() {
        if (this.activeStatus) {
            super.deactivateMembership();  // Call the parent method to set activeStatus = false
            System.out.println("Premium membership deactivated successfully.");
        } else {
            System.out.println("Premium membership is already inactive.");
        }
    }


    // Calculate discount (if full payment is made)
    public void calculateDiscount() {
        if (this.isFullPayment) {
            this.discountAmount = 0.1 * premiumCharge;
            
            System.out.println("Discount applied: $" + discountAmount);
        } else {
            this.discountAmount = 0;
            System.out.println("No discount available. Full payment is required.");
        }
    }

    // Process payment
    public String payDueAmount(double amount) {
        if (isFullPayment) {
            return "Payment is already complete.";
        }

        double totalCharge = premiumCharge - discountAmount;

        if (this.paidAmount + amount > totalCharge) {
            return "Payment exceeds the required amount.";
        }

        this.paidAmount += amount;

        if (this.paidAmount >= totalCharge) {
            this.isFullPayment = true;
            calculateDiscount();
        }

        double remainingAmount = totalCharge - this.paidAmount;
        return "Payment successful. Remaining amount: $" + remainingAmount;
    }

    // Mark attendance
    public void markAttendance() {
        if (this.activeStatus) {
            this.attendance++;
            this.loyaltyPoints += 5;
        } else {
            System.out.println("Member is not active. Cannot mark attendance.");
        }
    }

    // Reset premium membership details
    public void revertPremiumMember() {
        super.resetMember();
        this.personalTrainer = "";
        this.isFullPayment = false;
        this.paidAmount = 0;
        this.discountAmount = 0;
    }

    // Display member details
    public void display() {
        super.display();
        System.out.println("Personal Trainer: " + personalTrainer);
        System.out.println("Paid Amount: $" + paidAmount);
        System.out.println("Full Payment Completed: " + (isFullPayment ? "Yes" : "No"));
        System.out.println("Remaining Amount: $" + (premiumCharge - paidAmount));
        if (isFullPayment) {
            System.out.println("Discount Amount: $" + discountAmount);
        }
    }
    
    @Override
public String toString() {
    return super.toString() + 
           String.format("\nTrainer: %s\nPaid Amount: %.2f\nPayment Status: %s\nDiscount: %.2f",
           personalTrainer, paidAmount, 
           (isFullPayment ? "Fully Paid" : "Pending"), 
           discountAmount);
}
 // Add file serialization
// Add file serialization
@Override
public String toFileString() {
    return String.format("Premium,%d,%s,%s,%s,%s,%s,%s,%s,%s,%.2f,%b,%.2f",
        id, name, location, phone, email, gender, DOB, 
        membershipStartDate, personalTrainer, paidAmount, isFullPayment, discountAmount);
}


public static PremiumMember fromFileString(String[] parts) {
    int id = Integer.parseInt(parts[1]);
    String name = parts[2];
    String location = parts[3];
    String phone = parts[4];
    String email = parts[5];
    String gender = parts[6];
    String DOB = parts[7];
    String startDate = parts[8];
    String trainer = parts[9];
    
    PremiumMember member = new PremiumMember(id, name, location, phone, email, gender, DOB, startDate, trainer);
    
    // Set additional fields after construction
    member.paidAmount = Double.parseDouble(parts[10]);
    member.isFullPayment = Boolean.parseBoolean(parts[11]);
    member.discountAmount = Double.parseDouble(parts[12]);
    
    return member;
}

}
