public class RegularMember extends GymMember {
    private final int AttendanceLimit;
    private boolean isEligibleForUpdate;
    private String removalReasons;
    private String plan;
    private double price;
    private String referralSource;

    // Constructor
    public RegularMember(int id, String name, String location, String phone, String email, 
                        String gender, String DOB, String membershipStartDate, String referralSource) {
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        this.isEligibleForUpdate = false;
        this.AttendanceLimit = 30;
        this.price = 6500;
        this.plan = "Basic";
        this.referralSource = referralSource;
        this.removalReasons = "";
    }

    // Getters
    public int getAttendanceLimit() { 
        return AttendanceLimit; 
    }
    
    public boolean isEligibleForUpdate() { 
        return isEligibleForUpdate; 
    }
    
    public String getRemovalReasons() { 
        return removalReasons; 
    }
    
    public String getReferralSource() { 
        return referralSource; 
    }
    
    public double getPrice() { 
        return price; 
    }
    
    public String getPlan() { 
        return plan; 
    }

    // Setters
    public void setRemovalReasons(String reason) {
         this.removalReasons =reason;
    }
    
    public void setPlan(String plan) {
        this.plan = plan;
        this.price = getPlanPrice(plan);
    }

    @Override
    public void activateMembership() {
        if (!this.activeStatus) {
            super.activateMembership();
            System.out.println("Regular membership activated successfully.");
        } else {
            System.out.println("Regular membership is already active.");
        }
    }
    
    @Override
    public void deactivateMembership() {
        if (this.activeStatus) {
            super.deactivateMembership();
            System.out.println("Regular membership deactivated successfully.");
        } else {
            System.out.println("Regular membership is already inactive.");
        }
    }

    @Override
    public void markAttendance() {
        if (this.activeStatus) {
            this.attendance++;
            this.loyaltyPoints += 5;
        } else {
            System.out.println("Member is not active. Cannot mark attendance.");
        }
    }

    public double getPlanPrice(String plan) {
        switch (plan.toLowerCase()) {
            case "basic":
                return 6500;
            case "standard":
                return 12500;
            case "deluxe":
                return 18500;
            default:
                System.out.println("Invalid plan. Keeping the current plan: " + this.plan);
                return this.price;
        }
    }
    
    public double calculateDiscount() {
        if (attendance >= 20) {
            return price * 0.1; // 10% discount for high attendance
        }
        return 0;
    }

    public void display() {
        super.display();
        System.out.println("Plan: " + plan);
        System.out.println("Plan Price: $" + price);
        System.out.println("Referral Source: " + referralSource);
        System.out.println("Attendance Limit: " + AttendanceLimit);
        System.out.println("Eligible for Update: " + (isEligibleForUpdate ? "Yes" : "No"));
        if (!removalReasons.isEmpty()) {
            System.out.println("Removal Reasons: " + removalReasons);
        }
    }
    
    @Override
    public String toString() {
        return super.toString() + 
               String.format("\nPlan: %s\nPrice: %.2f\nReferral: %s\nEligible for Upgrade: %s",
               plan, price, referralSource, isEligibleForUpdate);
    }

    @Override
    public String toFileString() {
        return String.format("Regular,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%b",
            id, name, location, phone, email, gender, DOB, 
            membershipStartDate, plan, referralSource, isEligibleForUpdate);
    }

    public static RegularMember fromFileString(String[] parts) {
        if (parts.length != 12) {
            throw new IllegalArgumentException("Invalid data format for RegularMember");
        }
        
        int id = Integer.parseInt(parts[1]);
        String name = parts[2];
        String location = parts[3];
        String phone = parts[4];
        String email = parts[5];
        String gender = parts[6];
        String DOB = parts[7];
        String startDate = parts[8];
        String referral = parts[10];
        
        RegularMember member = new RegularMember(id, name, location, phone, email, 
                                              gender, DOB, startDate, referral);
        member.setPlan(parts[9]);
        member.isEligibleForUpdate = Boolean.parseBoolean(parts[11]);
        
        return member;
    }
}