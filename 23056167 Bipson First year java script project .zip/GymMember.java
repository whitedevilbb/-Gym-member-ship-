public abstract class GymMember { 
    // Protected attributes (accessible in subclasses)
    protected int id; 
    protected String name;
    protected String location;
    protected String phone;
    protected String email;
    protected String gender;
    protected String DOB;
    protected String membershipStartDate;
    protected int attendance;
    protected double loyaltyPoints;
    protected boolean activeStatus;

    // Constructor
    public GymMember(int id, String name, String location, String phone, String email, String gender, String DOB, String membershipStartDate) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.phone = phone;
        this.email = email;
        this.gender = gender;
        this.DOB = DOB;
        this.membershipStartDate = membershipStartDate;

        // Initialize attendance and loyalty points
        this.attendance = 0;
        this.loyaltyPoints = 0.0;
        this.activeStatus = false; // Membership starts as inactive
    }

    // Getter methods
    public int getId() { 
        return id;
    }
    public String getName() { 
        return name; 
    }
    public String getLocation() { 
        return location; 
    }
    public String getPhone() { 
        return phone; 
    }
    public String getEmail() { 
        return email; 
    }
    public String getDOB() { 
        return DOB; 
    }
    public String getMembershipStartDate() { 
        return membershipStartDate; 
    }
    public int getAttendance() { 
        return attendance; 
    }
    public double getLoyaltyPoints() { 
        return loyaltyPoints; 
    }
    public boolean isActive() { 
        return activeStatus; 
    }

    // Abstract method (to be implemented in subclasses)
    public abstract void markAttendance();

    // Method to activate membership
    public void activateMembership() {
        if (!this.activeStatus) {
            this.activeStatus = true;
            System.out.println("Membership activated successfully.");
        } else {
            System.out.println("Membership is already active.");
        }
    }

    // Method to deactivate membership (only if active)
    public void deactivateMembership() {
        if (this.activeStatus) {
            this.activeStatus = false;
            System.out.println("Membership deactivated successfully.");
        } else {
            System.out.println("Cannot deactivate. Membership is already inactive.");
        }
    }
    // Reset member details
    public void resetMember() {
        this.activeStatus = false;
        this.attendance = 0;
        this.loyaltyPoints = 0;
    }

    // Display member details
    public void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Location: " + location);
        System.out.println("Phone: " + phone);
        System.out.println("Email: " + email);
        System.out.println("Gender: " + gender);
        System.out.println("Date of Birth: " + DOB);
        System.out.println("Membership Start Date: " + membershipStartDate);
        System.out.println("Attendance: " + attendance);
        System.out.println("Loyalty Points: " + loyaltyPoints);
        System.out.println("Active Status: " + (activeStatus ? "Active" : "Inactive"));
    }
    
    @Override
public String toString() {
    return String.format(
        "ID: %d\nName: %s\nLocation: %s\nPhone: %s\nEmail: %s\nGender: %s\nDOB: %s\nStart Date: %s\nAttendance: %d\nLoyalty Points: %.1f\nStatus: %s",
        id, name, location, phone, email, gender, DOB, membershipStartDate, 
        attendance, loyaltyPoints, (activeStatus ? "Active" : "Inactive")
    );
}

// Add these methods for file I/O
// Add these methods for file I/O
public abstract String toFileString();  // To be implemented in subclasses

public static GymMember fromFileString(String line) {
    // Parse the line and return a GymMember (Regular/Premium)
    // Example format: "type,id,name,location,..."
    String[] parts = line.split(",");
    if (parts[0].equals("Regular")) {
        return RegularMember.fromFileString(parts);
    } else if (parts[0].equals("Premium")) {
        return PremiumMember.fromFileString(parts);
    }
    return null;
}
}